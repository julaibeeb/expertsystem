<?php
if (isset($_POST['value'])) {
    require 'dbpdo.php';
    if (!empty($_POST['value'])) {
        $value = $_POST['value'];
        $id = $_COOKIE['userid'];
        $query = "SELECT malarialevel FROM patientrecord WHERE id='$id'";
        $result = $conn->query($query);
        if ($result) {
            if ($result->num_rows > 0) {
                $record = $result->fetch_assoc();
                $lastvalue = $record['malarialevel'];
                $updatedvalue = $value + $lastvalue;
                echo $updatedvalue;
                $sql = "UPDATE patientrecord SET malarialevel='$updatedvalue' WHERE id='$id'";
                $resultupdate = $conn->query($sql);
                if ($resultupdate) {
                    echo 'success';
                } else {
                    echo $conn->error;
                }
            }
        } else {
            echo $conn->error;
        }
    } else {
        ?>
        }
        <script src="jquery.js" type="text/javascript"></script>
        <script src="sweetalert.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                swal('Success', 'recorded', 'success');
            })
        </script>
        <?php
    }
} else {
    echo "no";
}