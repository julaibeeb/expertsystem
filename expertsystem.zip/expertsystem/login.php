<?php

if (isset($_POST['email'], $_POST['pass'])) {
    require 'dbpdo.php';

    $email = $_POST['email'];
    $password = md5($_POST['pass']);
    $query = "SELECT * FROM patientrecord WHERE email='$email' AND password='$password'";
    $result = $conn->query($query);
    if ($result) {
        if ($result->num_rows > 0) {
            $record = $result->fetch_assoc();
            $userid = $record['id'];
            $_SESSION['userid'] = $userid;
            setcookie("userid", $userid, time()+360);
            header('location: index.php');
        }
    } else {
        echo $conn->error;
    }
} else {
    echo "no";
}