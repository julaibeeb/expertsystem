<?php

if(isset($_POST['userid'])){
    require 'dbpdo.php';
    $id = $_COOKIE['userid'];
    $level = '';
    $query = "SELECT * FROM patientrecord WHERE id='$id'";
    $result = $conn->query($query);
    if ($result) {
        if ($result->num_rows > 0) {
            $record = $result->fetch_assoc();
            $malarialevel = $record['malarialevel'];
            if($malarialevel >= 75){
                $level .='<p style="color:red" >your Malaria level is <b>Very High</b>, kindly seek advice immediately from a physician</p>';
            }elseif ($malarialevel >=65) {
                $level .='<p style="color:blue" >your Malaria level is  <b>High</b>, please seek advice from a Doctor for medical</p>';
            }elseif($malarialevel >=45){
                $level .='<p style="color:teal" >your Malaria level is <b>Average</b>, you should seek an advice from a physician for medications</p>';
            }elseif($malarialevel >=11){
                $level .='<p style="color:green" >your Malaria level is <b>Low</b>, but don\'t wait, seek advice from a physician</p>';
            }elseif ($malarialevel <=10) {
                $level .='<p style="color:green" >your Malaria level is <b>Zero</b>, which means you have no malaria, thank you</p>';
            }
            echo $level;
        }
    } else {
        echo $conn->error;
    }
}