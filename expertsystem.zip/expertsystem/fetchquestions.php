<?php

if(isset($_POST['val'])){
    echo 'yes';
}

