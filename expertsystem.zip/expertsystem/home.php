<?php
if (isset($_COOKIE['userid']) && !empty($_COOKIE['userid'])) {
    ?>

    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <script src="jquery.js" type="text/javascript"></script>
            <script src="sweetalert.min.js" type="text/javascript"></script>
            <link href="jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
            <script src="jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
            <link href="semantic-ui/semantic.min.css" rel="stylesheet" type="text/css"/>
            <title></title>
        </head>
        <body>
            <div class="ui container">
                <table class="ui padded striped table">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Question</th>
                            <th>Yes</th>
                            <th>No</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php
    require 'dbpdo.php';
    $query = "SELECT * FROM symptoms";
    $statement = $conn->query($query);
    if ($statement) {
        // $result = mysqli_fetch_all($statement, MYSQLI_BOTH);
        while ($result = $statement->fetch_assoc()) {
            ?>
                                <tr>
                                    <td><?php echo $result['id'] ?></td>
                            <input type="hidden" value="<?php $result['id']; ?>" class="patientid"/>
                            <td><?php echo $result['question'] . " " . $result['symptom'] ?></td>
                            <td><input type="submit" value="Yes" id="<?php echo $result['id'] ?>" data-action="yes" data-value="<?php echo $result['value'] ?>" class="ui teal button b" ></td>
                            <td><input type="submit" value="No" id="<?php echo $result['id'] . $result['id'] ?>" data-action="no" data-value="<?php echo $result['value'] ?>" class="ui olive button b"></td>
                            </tr>
            <?php
        }
        ?>
                        <tr><td colspan="2"></td><td><center><button class="ui green basic button sub">Submit</button></center></td></tr>
                        </tbody>
                    </table>
        <?php
    }
    ?>
            </div>
        </body>
    </html>
    <?php
} else {
    
}
?>
<script>
    $(document).ready(function () {
        $(".b").click(function () {
            var action = $(this).data("action");
            var id = $(this).attr("id");
            var patient = $(".patientid").val();
            var empty = "";
            if (action == "yes") {
                var value = $(this).data("value");
                var patientid = patient;
            } else {
                var value = empty;
                var patientid = empty;
            }
            $.ajax({
                url: "updaterecord.php",
                method: "POST",
                data: {value: value, id: id},
                beforeSend: function () {
                    if (action == "yes") {
                        $("#" + id).val("Sending..")
                        $("#" + id).removeClass("ui teal button")
                        $("#" + id).addClass("ui red button")
                    } else {
                        $("#" + id).val("Sending..")
                        $("#" + id).removeClass("ui olive button")
                        $("#" + id).addClass("ui red button")
                    }
                },
                success: function (data) {
                    $("#" + id).val("Sent")
                    $("#" + id).attr("disabled", "disabled");
                    $("#" + id).removeClass("ui red button");
                    $("#" + id).removeClass("ui teal button")
                    $("#" + id).addClass("ui green button");
                }
            })
        });
    })

</script>